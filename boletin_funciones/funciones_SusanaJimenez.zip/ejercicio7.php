	<?php
	
	function cabecera ( $titulo  )
	{
		if ( empty($titulo) )
		{
			$titulo =  basename($_SERVER['PHP_SELF']); 
		}
		
		echo "<html>";
		echo "<head>";
		echo "<meta charset='UTF-8'>";
		echo "<title>$titulo</title>";
		echo "</head>";
	}
		
	$titulo = "Titulo titulo ";
	cabecera($titulo);
	

	?>
		
		<body>
		</body>
	</html>