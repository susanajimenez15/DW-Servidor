<html>
	<head>
		<meta charset="UTF-8">
		<title>Ejercicio 4</title>
	</head>
		
		<?php
		
		function sinEspacios($cadena)
		{
			// Elimina los espacios del principio, del final y los sobrantes
			// Si le quisieramos meter un 2 parametro, podriamos indicarle si quitar tabulaciones...etc
			trim($cadena);
				
			$cadenaFinal = str_replace("  "," ", $cadena);
			return $cadenaFinal;
		}
		
		function sinTildes($cadena)
		{
			$vocales = [
					"a" => "á" ,
					"e" => "é",
					"i" => "í",
					"o" => "ó",
					"u" => "ú"];
		
			$vocales2 = [
					"a" => "à" ,
					"e" => "è",
					"i" => "ì",
					"o" => "ò",
					"u" => "ù"];
		
			foreach($vocales as $idx => $vocal)
			{
				$cadena = str_replace($vocal, $idx, $cadena);
			}
			foreach($vocales2 as $idx => $vocal)
			{
				$cadena = str_replace($vocal, $idx, $cadena);
			}
		
			return $cadena;
		}
		
		function compCaseEsp($cadena1, $cadena2)
		{
			if ( strcmp($cadena1, $cadena2) == 0 )
			{
				echo "Las cadenas son iguales (sin contar tildes, ni mayusculas)";
			}
			else
			{
				echo "Las cadenas no son iguales";
			}
		}
		
		
		$cadena1 = strtolower("Hola carácola");
		$cadena2 = strtolower("Hòla cAracola");
		
		echo "Hola carácola"."</br>"."Hòla cAracola";
		
		$cadena11 = sinEspacios($cadena1);
		$cadena111 = sinTildes($cadena1);
		
		$cadena22 = sinEspacios($cadena2);
		$cadena222 = sinTildes($cadena2);
		
		echo "</br>";
		compCaseEsp($cadena111, $cadena222);

		?>
		
		<body>
		</body>
	</html>