<html>
	<head>
		<meta charset="UTF-8">
		<title>Ejercicio 3</title>
	</head>
		
		<?php
		
		function sinEspacios($cadena)
		{
			// Elimina los espacios del principio, del final y los sobrantes
			// Si le quisieramos meter un 2 parametro, podriamos indicarle si quitar tabulaciones...etc
			trim($cadena);
			
			$cadenaFinal = str_replace("  "," ", $cadena);
			return $cadenaFinal;
		}
		
		$cadena = " Hola  caracola  ";
		$cadena2 = " H   o   l    a";
		
		echo sinEspacios($cadena);
		echo "</br>";
		echo sinEspacios($cadena2);
		
		
		?>
		
		<body>
		</body>
	</html>