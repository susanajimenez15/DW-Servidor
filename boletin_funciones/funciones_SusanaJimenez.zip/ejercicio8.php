	<?php
	
	function cabecera ( $titulo  )
	{
		if ( empty($titulo) | !isset($titulo))
		{
			$titulo =  basename($_SERVER['PHP_SELF']); 
		}
		
		echo "<html>";
		echo "<head>";
		echo "<meta charset='UTF-8'>";
		echo "<title>$titulo";
	}
		
	function pie ()
	{
		echo "</title>";
		echo "</head>";
		echo "<body></body>";
		echo "</html>";
	}
	
	$titulo = "";
	cabecera($titulo);
	pie();

	?>
		
		
		
	