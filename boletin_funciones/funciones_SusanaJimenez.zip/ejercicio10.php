<html>
	<head>
		<meta charset="UTF-8">
		<title>Ejercicio 10 </title>
	</head>

<?php

	function circunferencia ($radio)
	{
		
		$area = ($radio*$radio) * pi();
		$perimetro = 2 * pi()* $radio;
		
		return "Area = ".$area." y perímetro = ".$perimetro;
	}
	
	echo circunferencia(45);
?>
<body>
</body>

</html>