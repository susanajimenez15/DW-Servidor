<?php
	// Biblioteca de funciones
	
	// Quitar tildes a cadenas
	// Tenemos en cuenta la tilde abierta y cerrada
	function sinTildes($cadena)
	{
		$vocales = [
				"a" => "á" ,
				"e" => "é",
				"i" => "í",
				"o" => "ó",
				"u" => "ú"];
	
		$vocales2 = [
				"a" => "à" ,
				"e" => "è",
				"i" => "ì",
				"o" => "ò",
				"u" => "ù"];
	
		foreach($vocales as $idx => $vocal)
		{
			$cadena = str_replace($vocal, $idx, $cadena);
		}
		foreach($vocales2 as $idx => $vocal)
		{
			$cadena = str_replace($vocal, $idx, $cadena);
		}
	
		return $cadena;
	}
	
	// Quitar espacios al principio y final.
	// Sustituye los dobles espacios blancos por uno solo
	function sinEspacios($cadena)
	{
		// Elimina los espacios del principio, del final y los sobrantes
		// Si le quisieramos meter un 2 parametro, podriamos indicarle si quitar tabulaciones...etc
		trim($cadena);
			
		$cadenaFinal = str_replace("  "," ", $cadena);
		return $cadenaFinal;
	}
	
	// Compara dos cadenas
	// No tiene en cuenta tildes ni mayusculas
	function compCaseEsp($cadena1, $cadena2)
	{
		if ( strcmp($cadena1, $cadena2) == 0 )
		{
			echo "Las cadenas son iguales (sin contar tildes, ni mayusculas)";
		}
		else
		{
			echo "Las cadenas no son iguales";
		}
	}
	
	
?>