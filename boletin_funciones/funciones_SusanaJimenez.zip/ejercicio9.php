<html>
	<head>
		<meta charset="UTF-8">
		<title>Ejercicio 9 </title>
	</head>

<?php

	function potencia ($numero , $exponente)
	{

		
		
	}
	
?>
<body>
</body>

</html>