<html>
<head>
<meta charset="UTF-8">
<title>Ejercicio 6</title>
</head>

	<?php
	
	function negrita ($texto)
	{
		$textoNegrita = "<b>".$texto."</b>";
		
		return $textoNegrita;
	}
		
	$texto = "fdas fsa dsadad sa sda dsa ";
	echo negrita($texto);
	
	?>
		
		<body>
		</body>
	</html>